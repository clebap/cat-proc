
**Código de clasificación:** {codigo}
**Familia:** {familia}

---

### OBJETO / DESCRIPCIÓN

{descripcion}

### FORMA DE PRESENTACIÓN

{forma_presentacion}

### PLAZO DE PRESENTACIÓN

{plazo_presentacion}

### FORMA DE INICIACIÓN

{forma_iniciacion}

### REQUISITOS Y DOCUMENTACIÓN

{requisitos}

### ÓRGANO DE RESOLUCIÓN

{organo_resolucion}

### EFECTO DEL SILENCIO

{efecto_silencio}

### NORMATIVA APLICABLE

{normativa}

### RECURSOS

{recursos}

### DIAGRAMA

```mermaid
{diagrama}
```

[← Volver al catálogo de procedimientos](../buscador.md)